
#import <UIKit/UIKit.h>

//! Project version number for Halo.
//FOUNDATION_EXPORT double HaloVersionNumber;

//! Project version string for Halo.
FOUNDATION_EXPORT const unsigned char HaloVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Halo/PublicHeader.h>


