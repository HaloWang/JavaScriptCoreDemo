//
//  ViewController.swift
//  JavaScriptCoreDemo_WangCe
//
//  Created by 王策 on 16/3/2.
//  Copyright © 2016年 王策. All rights reserved.
//

import UIKit
import JavaScriptCore
import Halo

class ViewController: UIViewController {
    
    @IBOutlet weak var webView: UIWebView!
    
    var context : JSContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let requestURLString = NSBundle.mainBundle().pathForResource("JavaScriptCoreDemo", ofType: "html")
        
        if let requestURLString = requestURLString,
            let requestURL = NSURL(string: requestURLString) {
                webView.loadRequest(NSURLRequest(URL: requestURL))
        }
        
    }
    
    @IBAction func rightBarButtonClick(sender: UIBarButtonItem) {
        
    }
}
